package com.dragon.fruit.service;

import java.util.Map;

/**
 * banner service
 */
public interface IBannerService {
    /**
     * 查询bannner 列表
     * @return
     */
    Map<String,Object> listBanner();
}
