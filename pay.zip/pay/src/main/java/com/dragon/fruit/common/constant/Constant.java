package com.dragon.fruit.common.constant;

/**
 * @program fruit
 * @description: 常量类
 * @author: Gaofei
 * @create: 2018/11/07 13:54
 */

public class Constant {

    public static final String KEY = "dragonguoshi20181107";
}
